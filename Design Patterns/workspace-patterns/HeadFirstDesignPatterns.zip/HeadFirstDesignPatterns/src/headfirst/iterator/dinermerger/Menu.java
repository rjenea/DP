package headfirst.iterator.dinermerger;

public interface Menu {
	public Iterator createIterator();
}
