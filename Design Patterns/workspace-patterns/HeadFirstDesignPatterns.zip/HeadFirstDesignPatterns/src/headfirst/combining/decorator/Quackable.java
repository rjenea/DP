package headfirst.combining.decorator;

public interface Quackable {
	public void quack();
}
